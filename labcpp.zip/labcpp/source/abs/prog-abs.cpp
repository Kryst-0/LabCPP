#include<iostream.h>
#include<conio.h>


main(){
  int a;
  cout<<"Inserisci il numero intero per il calcolo del valore assoluto ";
  cin>>a;
  cout<<"il valore assoluto di "<<a<<" e' ";
  if(a<0){
    a=a*-1; 
  }
  cout<<a<<endl;

  
  cout<<"premi un tasto per continuare";
  getch();
  
}