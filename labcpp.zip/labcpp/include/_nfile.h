/*  _nfile.h

    Maximum number of open files

*/

/*
 *      C/C++ Run Time Library - Version 8.0
 *
 *      Copyright (c) 1991, 1997 by Borland International
 *      All Rights Reserved.
 *
 */
/* $Revision:   8.1  $ */

#ifndef ___NFILE_H
#define ___NFILE_H

#if !defined(__FLAT__)

#define _NFILE_ 50

#else

#define _NFILE_ 50

#endif

#endif
